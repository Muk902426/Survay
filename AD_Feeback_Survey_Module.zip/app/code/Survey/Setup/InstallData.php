<?php

namespace Ad\Survey\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
  protected $_postFactory;

  public function __construct(\Ad\Survey\Model\GridFactory $postFactory)
  {
    $this->_postFactory = $postFactory;
  }

  public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
  {
    $data = [
      'name' => "Ad",
      'content' => 'Welcome to Ad Feedback Survay Form'
    ];
    $post = $this->_postFactory->create();
    $post->addData($data)->save();
  }
}