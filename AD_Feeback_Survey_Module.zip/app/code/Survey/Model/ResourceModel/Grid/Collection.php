<?php


namespace Ad\Survey\Model\ResourceModel\Grid;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'survey_id';
    /**
     * Define resource model.
     */
    protected function _construct()
    {
        $this->_init(
            'Ad\Survey\Model\Grid',
            'Ad\Survey\Model\ResourceModel\Grid'
        );
    }
}
