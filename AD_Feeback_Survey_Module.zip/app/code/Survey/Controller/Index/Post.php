<?php
namespace Ad\Survey\Controller\Index;

class Post extends \Magento\Framework\App\Action\Action
{
/**
 * @var \Magento\Framework\App\Config\ScopeConfigInterface
 */
protected $scopeConfig;

/**
 * @param \Magento\Framework\App\Action\Context $context
 * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
 */
public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
) {
    parent::__construct($context);
    $this->scopeConfig = $scopeConfig;
}

public function execute()
{
    $data = $this->getRequest()->getPostValue();
    $name = $data['name'];
    $content = $data['content'];
    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $question = $objectManager->create('Ad\Survey\Model\Grid');
    $question->setData($data);
    $question->setName($name);
    $question->setContent($content);
        $this->messageManager->addSuccess('Thanks for your valuable feedback.');
        $question->save();
        $this->_redirect('*/*/');
        return;
}
}
