<?php
namespace Ad\Survey\Block;

class Survey extends \Magento\Framework\View\Element\Template
{
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
    public function getFormAction()
    {
        return $this->getUrl('survey/index/post');
    }
}
